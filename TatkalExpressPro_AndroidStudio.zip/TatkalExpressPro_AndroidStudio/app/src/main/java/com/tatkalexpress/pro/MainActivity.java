package com.tatkalexpress.pro;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
public class MainActivity extends Activity {
  private WebView web;
  @Override public void onCreate(Bundle b) { super.onCreate(b);
    getWindow().setStatusBarColor(0xff090909); getWindow().setNavigationBarColor(0xff090909);
    web = new WebView(this); setContentView(web);
    web.getSettings().setJavaScriptEnabled(true);
    web.getSettings().setDomStorageEnabled(false);
    web.getSettings().setAllowFileAccess(true);
    web.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
        Uri uri=req.getUrl(); if ("https".equals(uri.getScheme()) || "http".equals(uri.getScheme())) { startActivity(new Intent(Intent.ACTION_VIEW,uri)); return true; } return false;
      }
    });
    web.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
        startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.irctc.co.in/nget/train-search"))); return false;
      }
    });
    web.loadUrl("file:///android_asset/index.html");
  }
  @Override public void onBackPressed(){ if(web.canGoBack()) web.goBack(); else super.onBackPressed(); }
}
