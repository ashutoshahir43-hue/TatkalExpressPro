# Tatkal Express Pro — Android Studio project

This is an independent offline booking-preparation app, **not** an IRCTC integration or ticket-purchasing bot. It cannot guarantee ticket availability.

## Build an APK
1. Open this folder in Android Studio.
2. Install Android SDK 35 if prompted, and allow Gradle sync.
3. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK will appear at `app/build/outputs/apk/debug/app-debug.apk`.
5. Install on your Android phone (you may need to permit installation from your file manager).

All passenger details are held in the page only while it is open. The app does not collect or save credentials, OTPs, or payment data. The IRCTC button opens the official website in the browser. The countdown is based on device time and does not check railway availability.
